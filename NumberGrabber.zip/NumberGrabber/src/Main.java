import java.io.BufferedReader;
import java.io.BufferedWriter;

		
		List<String> alreadyUsedNumbers = new ArrayList<>();
		Scanner ns = new Scanner(new File("alreadyusednumbers.txt"));
		while(ns.hasNextLine()) {
			alreadyUsedNumbers.add(ns.nextLine());
		}
		ns.close();
		

					String found = m.group().replace(" ", "");
					if(!numbers.contains(found) && !alreadyUsedNumbers.contains(found) && found.length() == length) {
						numbers.add(found);
						System.out.println(prefix + found);
					}
				}
			} catch (Throwable e) {
				new Exception("Finished crawling at page " + i, e).printStackTrace();
				break;
			}
		}
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File("alreadyusednumbers.txt"), true));
		for(String number : numbers) {
			writer.write(number);
			writer.newLine();
			writer.flush();
		}
		writer.close();
	}

}
